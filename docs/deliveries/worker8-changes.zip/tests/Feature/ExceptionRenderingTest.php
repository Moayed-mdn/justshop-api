<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Enums\ErrorCode;
use Illuminate\Support\Facades\Route;
use Tests\TestCase;

class ExceptionRenderingTest extends TestCase
{
    public function test_validation_exception_returns_the_unified_error_shape(): void
    {
        Route::post('/test-validation', function () {
            request()->validate(['name' => 'required']);
        });

        $response = $this->postJson('/test-validation', []);

        $response->assertStatus(422)
            ->assertJson([
                'success' => false,
                'code' => ErrorCode::VAL_001->value,
            ])
            ->assertJsonPath('message', fn ($message) => ! empty($message))
            ->assertJsonStructure(['errors' => ['name']]);
    }

    public function test_generic_exception_returns_generic_message_when_debug_is_off(): void
    {
        // The original version of this test asserted the raw exception
        // message unconditionally. ExceptionRegistrar only echoes the raw
        // message back when config('app.debug') is true; otherwise it
        // returns the translated error.internal_server_error string. That
        // made the old test's pass/fail depend on the ambient APP_DEBUG
        // value rather than on anything deterministic. Both states are
        // pinned down explicitly here.
        config(['app.debug' => false]);

        Route::get('/test-error-no-debug', function () {
            throw new \Exception('Custom server error message');
        });

        $response = $this->getJson('/test-error-no-debug');

        $response->assertStatus(500)->assertJson([
            'success' => false,
            'code' => ErrorCode::SYS_001->value,
            'message' => __('error.internal_server_error'),
        ]);
        $this->assertStringNotContainsString('Custom server error message', $response->getContent());
    }

    public function test_generic_exception_returns_raw_message_when_debug_is_on(): void
    {
        config(['app.debug' => true]);

        Route::get('/test-error-debug', function () {
            throw new \Exception('Custom server error message');
        });

        $response = $this->getJson('/test-error-debug');

        $response->assertStatus(500)->assertJson([
            'success' => false,
            'code' => ErrorCode::SYS_001->value,
            'message' => 'Custom server error message',
        ]);
    }

    public function test_unmatched_route_returns_str_001_not_found_code(): void
    {
        // Finding: NotFoundHttpException (any unmatched route, not just a
        // missing store) is mapped to ErrorCode::STR_001, the same code used
        // for App\Exceptions\Store\StoreNotFoundException. A client hitting
        // a typo'd URL and a client hitting a real "store not found" get an
        // identical error code, which could be confusing for API consumers
        // trying to branch on `code`. Captured as current behavior; worth
        // asking whether generic 404s should get their own code.
        $response = $this->getJson('/non-existent-route');

        $response->assertStatus(404)->assertJson([
            'success' => false,
            'code' => ErrorCode::STR_001->value,
        ]);
    }

    public function test_authentication_exception_returns_auth_002(): void
    {
        Route::get('/test-auth-required', function () {
            throw new \Illuminate\Auth\AuthenticationException();
        });

        $response = $this->getJson('/test-auth-required');

        $response->assertStatus(401)->assertJson([
            'success' => false,
            'code' => ErrorCode::AUTH_002->value,
        ]);
    }

    public function test_authorization_exception_returns_access_denied_with_redirect(): void
    {
        Route::get('/test-forbidden', function () {
            throw new \Illuminate\Auth\Access\AuthorizationException('Not allowed.');
        });

        $response = $this->getJson('/test-forbidden');

        $response->assertStatus(403)->assertJson([
            'success' => false,
            'code' => ErrorCode::ACCESS_DENIED->value,
            'redirect' => '/dashboard',
        ]);
    }

    public function test_a_generic_http_exception_falls_back_to_prefixed_status_code(): void
    {
        Route::get('/test-teapot', function () {
            throw new \Symfony\Component\HttpKernel\Exception\HttpException(418, "I'm a teapot");
        });

        $response = $this->getJson('/test-teapot');

        $response->assertStatus(418)->assertJson([
            'success' => false,
            'code' => 'HTTP_418',
        ]);
    }

    public function test_error_responses_carry_the_correlation_id_header(): void
    {
        // Ties error rendering to the request-trace/correlation-ID system:
        // ExceptionRegistrar::attachTraceHeaders() should stamp every error
        // response with the configured correlation header, not just
        // successful responses.
        Route::get('/test-error-trace', function () {
            throw new \Exception('boom');
        });

        $response = $this->getJson('/test-error-trace');

        $response->assertHeader((string) config('observability.correlation_header'));
    }
}
