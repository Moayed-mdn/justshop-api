<?php

declare(strict_types=1);

namespace Tests\Feature\Observability;

use App\Enums\Platform\ImpersonationStatusEnum;
use App\Enums\RoleEnum;
use App\Models\AuditLog;
use App\Models\Impersonation;
use App\Models\Store;
use App\Models\User;
use App\Services\Platform\Impersonation\ImpersonationLifecycleManager;
use App\Support\Audit\AuditLoggerInterface;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Route;
use Tests\TestCase;

class AuditLoggerTest extends TestCase
{
    use RefreshDatabase;

    public function test_database_audit_logger_persists_safe_request_scoped_metadata(): void
    {
        /** @var User $user */
        $user = User::factory()->merchant()->create();
        /** @var Store $store */
        $store = Store::factory()->for($user, 'owner')->create();
        $user->stores()->attach($store->id, ['role' => 'store_admin']);

        Route::middleware(['api', 'auth:sanctum', 'store.context'])
            ->post('/api/v1/stores/{store}/test-observability/audit', function (
                AuditLoggerInterface $auditLogger
            ) {
                $auditLogger->record('observability.test', [
                    'safe' => 'value',
                    'password' => 'secret',
                    'nested' => [
                        'api_token' => 'abc123',
                    ],
                ]);

                return response()->json(['recorded' => true]);
            });

        $response = $this->actingAs($user)->postJson(
            "/api/v1/stores/{$store->id}/test-observability/audit"
        );

        $response->assertOk()->assertHeader('X-Correlation-ID');

        /** @var AuditLog $auditLog */
        $auditLog = AuditLog::query()->firstOrFail();

        $this->assertSame('observability.test', $auditLog->event);
        $this->assertSame($user->id, $auditLog->actor_id);
        $this->assertSame('merchant', $auditLog->actor_type);
        $this->assertSame($store->id, $auditLog->store_id);
        $this->assertSame($response->headers->get('X-Correlation-ID'), $auditLog->correlation_id);
        $this->assertNotNull($auditLog->membership_id);
        $this->assertSame('value', $auditLog->metadata['safe']);
        $this->assertSame('[REDACTED]', $auditLog->metadata['password']);
        $this->assertSame('[REDACTED]', $auditLog->metadata['nested']['api_token']);
    }

    public function test_finding_impersonation_activation_does_not_write_to_the_queryable_audit_log(): void
    {
        // Finding: ImpersonationLifecycleManager uses a separate
        // ImpersonationTelemetry service that writes only to the application
        // log (Log::warning), not to the AuditLog table that
        // DatabaseAuditLogger persists and that AuditLogPolicy/the platform
        // audit log screen reads from. This means impersonation sessions —
        // arguably the most sensitive platform action in the app, a platform
        // admin literally acting as another user — are invisible to anyone
        // reviewing the structured audit log. This may be an intentional
        // split (log-based telemetry vs. DB-based audit trail), but it is
        // worth confirming: should impersonation activity also land in
        // AuditLog so it shows up alongside billing/onboarding/store events?
        Log::spy();

        $initiator = User::factory()->create();
        $initiator->assignRole(RoleEnum::SUPER_ADMIN->value);
        $target = User::factory()->merchant()->create();

        $impersonation = Impersonation::create([
            'initiator_id' => $initiator->id,
            'target_id' => $target->id,
            'reason' => 'support ticket #123',
            'status' => ImpersonationStatusEnum::PENDING->value,
            'requested_at' => now(),
            'expires_at' => now()->addMinutes(60),
        ]);

        $request = Request::create('/api/v1/platform/impersonation/activate', 'POST');
        $session = app('session')->driver();
        $session->start();
        $request->setLaravelSession($session);

        app(ImpersonationLifecycleManager::class)->activate($request, $impersonation);

        Log::shouldHaveReceived('warning')->with('platform.impersonation.activated', \Mockery::any())->once();
        $this->assertSame(0, AuditLog::query()->count());
    }
}
