<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Models\Order;
use App\Models\Store;
use App\Models\User;
use App\Policies\PlatformOrderPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class PlatformOrderPolicyTest extends TestCase
{
    use RefreshDatabase;

    private PlatformOrderPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(PlatformOrderPolicy::class);
        Permission::findOrCreate(PermissionEnum::PLATFORM_ORDER_VIEW);
        Permission::findOrCreate(PermissionEnum::PLATFORM_ORDER_UPDATE_STATUS);
        Permission::findOrCreate(PermissionEnum::PLATFORM_ORDER_CANCEL);
        Permission::findOrCreate(PermissionEnum::PLATFORM_ORDER_REFUND);
    }

    private function makeOrder(Store $store): Order
    {
        return Order::create([
            'order_number' => 'ORD-' . uniqid(),
            'store_id' => $store->id,
            'subtotal' => 50,
            'total' => 50,
        ]);
    }

    public function test_user_with_permission_can_view_any_platform_orders(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::PLATFORM_ORDER_VIEW);

        $this->assertTrue($this->policy->viewAny($user)->allowed());
    }

    public function test_user_without_permission_is_denied_viewing_any_platform_orders(): void
    {
        $user = User::factory()->create();

        $response = $this->policy->viewAny($user);

        $this->assertTrue($response->denied());
    }

    public function test_permission_is_cross_store_by_design(): void
    {
        // PlatformOrderPolicy has no store-membership check at all: any user
        // with the platform permission can view an order from a store they
        // have zero relation to. This is intentional per the class docblock
        // ("Platform actors operate at platform level across all stores"),
        // captured here explicitly so a future change is caught.
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::PLATFORM_ORDER_VIEW);
        $unrelatedStore = Store::factory()->create();
        $order = $this->makeOrder($unrelatedStore);

        $this->assertTrue($this->policy->view($user, $order)->allowed());
    }

    public function test_user_with_permission_can_update_status(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::PLATFORM_ORDER_UPDATE_STATUS);
        $order = $this->makeOrder(Store::factory()->create());

        $this->assertTrue($this->policy->updateStatus($user, $order)->allowed());
    }

    public function test_user_without_permission_is_denied_cancel(): void
    {
        $user = User::factory()->create();
        $order = $this->makeOrder(Store::factory()->create());

        $this->assertTrue($this->policy->cancel($user, $order)->denied());
    }

    public function test_user_with_permission_can_refund(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::PLATFORM_ORDER_REFUND);
        $order = $this->makeOrder(Store::factory()->create());

        $this->assertTrue($this->policy->refund($user, $order)->allowed());
    }
}
