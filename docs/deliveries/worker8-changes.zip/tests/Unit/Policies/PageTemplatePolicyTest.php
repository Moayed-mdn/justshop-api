<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Enums\Store\StoreRoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Models\PageTemplate;
use App\Models\Store;
use App\Models\User;
use App\Policies\PageTemplatePolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class PageTemplatePolicyTest extends TestCase
{
    use RefreshDatabase;

    private PageTemplatePolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(PageTemplatePolicy::class);
        Permission::findOrCreate(PermissionEnum::TEMPLATE_VIEW);
        Permission::findOrCreate(PermissionEnum::TEMPLATE_CREATE);
        Permission::findOrCreate(PermissionEnum::TEMPLATE_UPDATE);
        Permission::findOrCreate(PermissionEnum::TEMPLATE_DELETE);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    public function test_super_admin_can_view_any_template(): void
    {
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);
        $store = Store::factory()->create();

        $this->assertTrue($this->policy->viewAny($superAdmin, $store));
    }

    public function test_store_admin_with_permission_can_view_a_template(): void
    {
        $admin = User::factory()->merchant()->create();
        $store = Store::factory()->for($admin, 'owner')->create();
        $admin->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $admin->givePermissionTo(PermissionEnum::TEMPLATE_VIEW);
        $template = PageTemplate::factory()->for($store)->create();

        $this->assertTrue($this->policy->view($admin, $template));
    }

    public function test_non_member_cannot_view_a_template(): void
    {
        $stranger = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $stranger->givePermissionTo(PermissionEnum::TEMPLATE_VIEW);
        $template = PageTemplate::factory()->for($store)->create();

        $this->assertFalse($this->policy->view($stranger, $template));
    }

    public function test_member_without_permission_throws_on_update(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $member = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $member->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);
        $template = PageTemplate::factory()->for($store)->create();

        $this->policy->update($member, $template);
    }

    public function test_store_admin_with_permission_can_create_template(): void
    {
        $admin = User::factory()->merchant()->create();
        $store = Store::factory()->for($admin, 'owner')->create();
        $admin->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $admin->givePermissionTo(PermissionEnum::TEMPLATE_CREATE);

        $this->assertTrue($this->policy->create($admin, $store));
    }

    public function test_store_admin_with_permission_can_delete_template(): void
    {
        $admin = User::factory()->merchant()->create();
        $store = Store::factory()->for($admin, 'owner')->create();
        $admin->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $admin->givePermissionTo(PermissionEnum::TEMPLATE_DELETE);
        $template = PageTemplate::factory()->for($store)->create();

        $this->assertTrue($this->policy->delete($admin, $template));
    }
}
