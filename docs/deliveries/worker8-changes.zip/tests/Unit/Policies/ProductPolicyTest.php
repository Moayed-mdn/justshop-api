<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\Entitlement\EntitlementStatusEnum;
use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Enums\Store\StoreRoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Exceptions\Subscription\SubscriptionRequiredException;
use App\Models\BillingAccount;
use App\Models\Store;
use App\Models\StoreEntitlementSnapshot;
use App\Models\User;
use App\Policies\ProductPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class ProductPolicyTest extends TestCase
{
    use RefreshDatabase;

    private ProductPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(ProductPolicy::class);
        Permission::findOrCreate(PermissionEnum::PRODUCT_VIEW);
        Permission::findOrCreate(PermissionEnum::PRODUCT_CREATE);
        Permission::findOrCreate(PermissionEnum::PRODUCT_UPDATE);
        Permission::findOrCreate(PermissionEnum::PRODUCT_DELETE);
        Permission::findOrCreate(PermissionEnum::PRODUCT_RESTORE);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    private function givesUnlimitedEntitlement(Store $store): void
    {
        $billingAccount = BillingAccount::create([
            'owner_user_id' => $store->owner_id,
            'billing_email' => 'billing@example.test',
            'status' => 'active',
        ]);

        StoreEntitlementSnapshot::create([
            'store_id' => $store->id,
            'billing_account_id' => $billingAccount->id,
            'entitlement_status' => EntitlementStatusEnum::ENTITLED,
            'features' => [], // no explicit limit key => treated as unlimited by FeatureGateService
            'products_count' => 0,
        ]);
    }

    public function test_super_admin_can_view_without_membership(): void
    {
        $user = User::factory()->create();
        $user->assignRole(RoleEnum::SUPER_ADMIN->value);
        $store = Store::factory()->create();

        $this->assertTrue($this->policy->view($user, $store));
    }

    public function test_store_admin_without_permission_cannot_view(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->for($user, 'owner')->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);

        $this->assertFalse($this->policy->view($user, $store));
    }

    public function test_member_without_permission_throws_on_view(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $user = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);

        $this->policy->view($user, $store);
    }

    public function test_non_member_cannot_view(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $user->givePermissionTo(PermissionEnum::PRODUCT_VIEW);

        $this->assertFalse($this->policy->view($user, $store));
    }

    public function test_create_denied_without_permission_never_reaches_quota_check(): void
    {
        // No StoreEntitlementSnapshot exists at all. If the quota check ran, this
        // would throw SubscriptionRequiredException instead of returning false.
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->for($user, 'owner')->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);

        $this->assertFalse($this->policy->create($user, $store));
    }

    public function test_create_with_permission_but_no_subscription_throws_subscription_required(): void
    {
        $this->expectException(SubscriptionRequiredException::class);

        $user = User::factory()->merchant()->create();
        $store = Store::factory()->for($user, 'owner')->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $user->givePermissionTo(PermissionEnum::PRODUCT_CREATE);

        $this->policy->create($user, $store);
    }

    public function test_create_with_permission_and_active_entitlement_succeeds(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->for($user, 'owner')->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $user->givePermissionTo(PermissionEnum::PRODUCT_CREATE);
        $this->givesUnlimitedEntitlement($store);

        $this->assertTrue($this->policy->create($user, $store));
    }

    public function test_store_admin_can_update_delete_restore_with_permission(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->for($user, 'owner')->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $user->givePermissionTo([
            PermissionEnum::PRODUCT_UPDATE,
            PermissionEnum::PRODUCT_DELETE,
            PermissionEnum::PRODUCT_RESTORE,
        ]);

        $this->assertTrue($this->policy->update($user, $store));
        $this->assertTrue($this->policy->delete($user, $store));
        $this->assertTrue($this->policy->restore($user, $store));
    }
}
