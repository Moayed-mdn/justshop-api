<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Enums\Store\StoreRoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Models\Store;
use App\Models\User;
use App\Policies\BrandPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class BrandPolicyTest extends TestCase
{
    use RefreshDatabase;

    private BrandPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(BrandPolicy::class);
        Permission::findOrCreate(PermissionEnum::BRAND_VIEW);
        Permission::findOrCreate(PermissionEnum::BRAND_CREATE);
        Permission::findOrCreate(PermissionEnum::BRAND_UPDATE);
        Permission::findOrCreate(PermissionEnum::BRAND_DELETE);
        Permission::findOrCreate(PermissionEnum::BRAND_RESTORE);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    public function test_super_admin_can_view_without_membership(): void
    {
        $user = User::factory()->create();
        $user->assignRole(RoleEnum::SUPER_ADMIN->value);
        $store = Store::factory()->create();

        $this->assertTrue($this->policy->view($user, $store));
    }

    public function test_store_admin_with_permission_can_view(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->for($user, 'owner')->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $user->givePermissionTo(PermissionEnum::BRAND_VIEW);

        $this->assertTrue($this->policy->view($user, $store));
    }

    public function test_store_admin_without_permission_cannot_view(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->for($user, 'owner')->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);

        $this->assertFalse($this->policy->view($user, $store));
    }

    public function test_member_with_permission_can_view(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);
        $user->givePermissionTo(PermissionEnum::BRAND_VIEW);

        $this->assertTrue($this->policy->view($user, $store));
    }

    public function test_member_without_permission_throws_on_view(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $user = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);

        $this->policy->view($user, $store);
    }

    public function test_non_member_cannot_view(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $user->givePermissionTo(PermissionEnum::BRAND_VIEW);

        $this->assertFalse($this->policy->view($user, $store));
    }

    public function test_non_member_cannot_create(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $user->givePermissionTo(PermissionEnum::BRAND_CREATE);

        $this->assertFalse($this->policy->create($user, $store));
    }

    public function test_member_without_permission_throws_on_create(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $user = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);

        $this->policy->create($user, $store);
    }

    public function test_store_admin_can_create_update_delete_restore_with_permission(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->for($user, 'owner')->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $user->givePermissionTo([
            PermissionEnum::BRAND_CREATE,
            PermissionEnum::BRAND_UPDATE,
            PermissionEnum::BRAND_DELETE,
            PermissionEnum::BRAND_RESTORE,
        ]);

        $this->assertTrue($this->policy->create($user, $store));
        $this->assertTrue($this->policy->update($user, $store));
        $this->assertTrue($this->policy->delete($user, $store));
        $this->assertTrue($this->policy->restore($user, $store));
    }

    public function test_store_admin_without_matching_permission_cannot_update(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->for($user, 'owner')->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);

        $this->assertFalse($this->policy->update($user, $store));
    }
}
