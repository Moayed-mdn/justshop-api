<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Enums\Store\StoreRoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Models\Order;
use App\Models\Store;
use App\Models\User;
use App\Policies\OrderPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class OrderPolicyTest extends TestCase
{
    use RefreshDatabase;

    private OrderPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(OrderPolicy::class);
        Permission::findOrCreate(PermissionEnum::ORDER_VIEW);
        Permission::findOrCreate(PermissionEnum::ORDER_CANCEL);
        Permission::findOrCreate(PermissionEnum::ORDER_UPDATE_STATUS);
        Permission::findOrCreate(PermissionEnum::ORDER_REFUND);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    private function makeOrder(?Store $store, ?User $customer): Order
    {
        return Order::create([
            'order_number' => 'ORD-' . uniqid(),
            'store_id' => $store?->id,
            'user_id' => $customer?->id,
            'subtotal' => 100,
            'total' => 100,
        ]);
    }

    public function test_customer_can_view_own_order(): void
    {
        $customer = User::factory()->customer()->create();
        $order = $this->makeOrder(Store::factory()->create(), $customer);

        $this->assertTrue($this->policy->view($customer, $order));
    }

    public function test_customer_cannot_view_someone_elses_order(): void
    {
        $customer = User::factory()->customer()->create();
        $owner = User::factory()->customer()->create();
        $order = $this->makeOrder(Store::factory()->create(), $owner);

        $this->assertFalse($this->policy->view($customer, $order));
    }

    public function test_merchant_member_with_permission_can_view_store_order(): void
    {
        $merchant = User::factory()->merchant()->create();
        $store = Store::factory()->for($merchant, 'owner')->create();
        $merchant->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $merchant->givePermissionTo(PermissionEnum::ORDER_VIEW);
        $order = $this->makeOrder($store, User::factory()->customer()->create());

        $this->assertTrue($this->policy->view($merchant, $order));
    }

    public function test_merchant_member_without_permission_throws_on_view(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $merchant = User::factory()->merchant()->create();
        $store = Store::factory()->for($merchant, 'owner')->create();
        $merchant->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);
        $order = $this->makeOrder($store, User::factory()->customer()->create());

        $this->policy->view($merchant, $order);
    }

    public function test_merchant_not_a_member_of_the_stores_order_cannot_view(): void
    {
        $merchant = User::factory()->merchant()->create();
        $otherStore = Store::factory()->create();
        $order = $this->makeOrder($otherStore, User::factory()->customer()->create());

        $this->assertFalse($this->policy->view($merchant, $order));
    }

    public function test_super_admin_without_active_impersonation_cannot_view_arbitrary_order(): void
    {
        // Unlike most other policies, OrderPolicy::view()/cancel() do NOT special-case
        // super_admin. A platform admin only gets access through the governed
        // impersonation path in HasStoreMembership::isMember(). This test locks in
        // that (intentional-looking, but worth confirming) behavioral difference.
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);
        $order = $this->makeOrder(Store::factory()->create(), User::factory()->customer()->create());

        $this->assertFalse($this->policy->view($superAdmin, $order));
    }

    public function test_customer_can_cancel_own_order(): void
    {
        $customer = User::factory()->customer()->create();
        $order = $this->makeOrder(Store::factory()->create(), $customer);

        $this->assertTrue($this->policy->cancel($customer, $order));
    }

    public function test_store_admin_with_permission_can_update_status(): void
    {
        $merchant = User::factory()->merchant()->create();
        $store = Store::factory()->for($merchant, 'owner')->create();
        $merchant->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $merchant->givePermissionTo(PermissionEnum::ORDER_UPDATE_STATUS);
        $order = $this->makeOrder($store, User::factory()->customer()->create());

        $this->assertTrue($this->policy->updateStatus($merchant, $order));
    }

    public function test_store_admin_without_permission_cannot_refund(): void
    {
        $merchant = User::factory()->merchant()->create();
        $store = Store::factory()->for($merchant, 'owner')->create();
        $merchant->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $order = $this->makeOrder($store, User::factory()->customer()->create());

        $this->assertFalse($this->policy->refund($merchant, $order));
    }
}
