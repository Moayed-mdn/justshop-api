<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Enums\Store\StoreRoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Models\Store;
use App\Models\User;
use App\Policies\Cms\Marketing\Store\StoreMarketingPagePolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class StoreMarketingPagePolicyTest extends TestCase
{
    use RefreshDatabase;

    private StoreMarketingPagePolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(StoreMarketingPagePolicy::class);
        Permission::findOrCreate(PermissionEnum::MARKETING_STORE_VIEW);
        Permission::findOrCreate(PermissionEnum::MARKETING_STORE_CREATE);
        Permission::findOrCreate(PermissionEnum::MARKETING_STORE_UPDATE);
        Permission::findOrCreate(PermissionEnum::MARKETING_STORE_DELETE);
        Permission::findOrCreate(PermissionEnum::MARKETING_STORE_PUBLISH);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    public function test_super_admin_can_view_without_membership(): void
    {
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);
        $store = Store::factory()->create();

        $this->assertTrue($this->policy->view($superAdmin, $store));
    }

    public function test_store_admin_with_permission_can_view(): void
    {
        $admin = User::factory()->merchant()->create();
        $store = Store::factory()->for($admin, 'owner')->create();
        $admin->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $admin->givePermissionTo(PermissionEnum::MARKETING_STORE_VIEW);

        $this->assertTrue($this->policy->view($admin, $store));
    }

    public function test_store_admin_without_permission_throws_unlike_sibling_policies(): void
    {
        // Unlike NavigationPolicy/ThemePolicy/BrandPolicy/etc., this policy's
        // canView() has no silent-false branch for an admin without the
        // permission — it always calls denyWithContext(), so this always
        // throws rather than returning false.
        $this->expectException(PermissionDeniedException::class);

        $admin = User::factory()->merchant()->create();
        $store = Store::factory()->for($admin, 'owner')->create();
        $admin->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);

        $this->policy->view($admin, $store);
    }

    public function test_non_member_throws_rather_than_returning_false(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $stranger = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $stranger->givePermissionTo(PermissionEnum::MARKETING_STORE_VIEW);

        $this->policy->view($stranger, $store);
    }

    public function test_store_admin_with_permission_can_create_update_delete_publish(): void
    {
        $admin = User::factory()->merchant()->create();
        $store = Store::factory()->for($admin, 'owner')->create();
        $admin->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $admin->givePermissionTo([
            PermissionEnum::MARKETING_STORE_CREATE,
            PermissionEnum::MARKETING_STORE_UPDATE,
            PermissionEnum::MARKETING_STORE_DELETE,
            PermissionEnum::MARKETING_STORE_PUBLISH,
        ]);

        $this->assertTrue($this->policy->create($admin, $store));
        $this->assertTrue($this->policy->update($admin, $store));
        $this->assertTrue($this->policy->delete($admin, $store));
        $this->assertTrue($this->policy->publish($admin, $store));
    }
}
