<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Models\PaymentMethod;
use App\Models\User;
use App\Policies\PaymentMethodPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class PaymentMethodPolicyTest extends TestCase
{
    use RefreshDatabase;

    private PaymentMethodPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(PaymentMethodPolicy::class);
        Permission::findOrCreate(PermissionEnum::PAYMENT_METHOD_UPDATE);
        Permission::findOrCreate(PermissionEnum::PAYMENT_METHOD_DELETE);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    public function test_owner_with_permission_can_update_own_payment_method(): void
    {
        $user = User::factory()->customer()->create();
        $user->givePermissionTo(PermissionEnum::PAYMENT_METHOD_UPDATE);
        $paymentMethod = PaymentMethod::factory()->for($user)->create();

        $this->assertTrue($this->policy->update($user, $paymentMethod));
    }

    public function test_owner_without_the_permission_grant_cannot_update_own_payment_method(): void
    {
        // Finding: PaymentMethodPolicy checks $user->can(PAYMENT_METHOD_UPDATE)
        // FIRST, before checking ownership. A customer who owns the payment
        // method but was never granted this permission is denied — worth
        // confirming that PAYMENT_METHOD_UPDATE is auto-granted to customers
        // by default (e.g. via a role), otherwise customers may be unable to
        // manage their own saved cards.
        $this->expectException(PermissionDeniedException::class);

        $user = User::factory()->customer()->create();
        $paymentMethod = PaymentMethod::factory()->for($user)->create();

        $this->policy->update($user, $paymentMethod);
    }

    public function test_non_owner_with_permission_cannot_update_someone_elses_payment_method(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $user = User::factory()->customer()->create();
        $user->givePermissionTo(PermissionEnum::PAYMENT_METHOD_UPDATE);
        $owner = User::factory()->customer()->create();
        $paymentMethod = PaymentMethod::factory()->for($owner)->create();

        $this->policy->update($user, $paymentMethod);
    }

    public function test_super_admin_with_permission_can_update_any_payment_method(): void
    {
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);
        $superAdmin->givePermissionTo(PermissionEnum::PAYMENT_METHOD_UPDATE);
        $owner = User::factory()->customer()->create();
        $paymentMethod = PaymentMethod::factory()->for($owner)->create();

        $this->assertTrue($this->policy->update($superAdmin, $paymentMethod));
    }

    public function test_owner_with_permission_can_delete_own_payment_method(): void
    {
        $user = User::factory()->customer()->create();
        $user->givePermissionTo(PermissionEnum::PAYMENT_METHOD_DELETE);
        $paymentMethod = PaymentMethod::factory()->for($user)->create();

        $this->assertTrue($this->policy->delete($user, $paymentMethod));
    }
}
