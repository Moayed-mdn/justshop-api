<?php

declare(strict_types=1);

namespace Tests\Unit\Policies\Platform;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Models\User;
use App\Policies\Platform\AuditLogPolicy;
use App\Policies\Platform\FeatureFlagPolicy;
use App\Policies\Platform\PlatformAnalyticsPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

/**
 * These three platform policies (AuditLogPolicy, FeatureFlagPolicy,
 * PlatformAnalyticsPolicy) share the exact same shape: `hasRole(SUPER_ADMIN)
 * && can(permission)`. Grouped in one file since each ability is a single
 * boolean expression with no other branches worth a dedicated file.
 */
class PlatformResourcePoliciesTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        Permission::findOrCreate(PermissionEnum::AUDIT_LOG_VIEW);
        Permission::findOrCreate(PermissionEnum::FEATURE_FLAG_VIEW);
        Permission::findOrCreate(PermissionEnum::FEATURE_FLAG_UPDATE);
        Permission::findOrCreate(PermissionEnum::PLATFORM_ANALYTICS_VIEW);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    public function test_super_admin_with_permission_can_view_audit_logs(): void
    {
        $user = User::factory()->create();
        $user->assignRole(RoleEnum::SUPER_ADMIN->value);
        $user->givePermissionTo(PermissionEnum::AUDIT_LOG_VIEW);

        $this->assertTrue(app(AuditLogPolicy::class)->viewAny($user));
    }

    public function test_super_admin_without_permission_cannot_view_audit_logs(): void
    {
        // Role alone is not enough — the explicit permission grant is required too.
        $user = User::factory()->create();
        $user->assignRole(RoleEnum::SUPER_ADMIN->value);

        $this->assertFalse(app(AuditLogPolicy::class)->viewAny($user));
    }

    public function test_non_admin_with_permission_still_cannot_view_audit_logs(): void
    {
        // Permission alone is not enough — the SUPER_ADMIN role is required too.
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::AUDIT_LOG_VIEW);

        $this->assertFalse(app(AuditLogPolicy::class)->viewAny($user));
    }

    public function test_super_admin_with_permission_can_view_feature_flags(): void
    {
        $user = User::factory()->create();
        $user->assignRole(RoleEnum::SUPER_ADMIN->value);
        $user->givePermissionTo(PermissionEnum::FEATURE_FLAG_VIEW);

        $this->assertTrue(app(FeatureFlagPolicy::class)->viewAny($user));
    }

    public function test_super_admin_with_permission_can_update_feature_flags(): void
    {
        $user = User::factory()->create();
        $user->assignRole(RoleEnum::SUPER_ADMIN->value);
        $user->givePermissionTo(PermissionEnum::FEATURE_FLAG_UPDATE);

        $this->assertTrue(app(FeatureFlagPolicy::class)->update($user));
    }

    public function test_super_admin_without_permission_cannot_update_feature_flags(): void
    {
        $user = User::factory()->create();
        $user->assignRole(RoleEnum::SUPER_ADMIN->value);

        $this->assertFalse(app(FeatureFlagPolicy::class)->update($user));
    }

    public function test_super_admin_with_permission_can_view_platform_analytics(): void
    {
        $user = User::factory()->create();
        $user->assignRole(RoleEnum::SUPER_ADMIN->value);
        $user->givePermissionTo(PermissionEnum::PLATFORM_ANALYTICS_VIEW);

        $this->assertTrue(app(PlatformAnalyticsPolicy::class)->viewAny($user));
    }

    public function test_merchant_cannot_view_platform_analytics_even_with_permission(): void
    {
        $user = User::factory()->merchant()->create();
        $user->givePermissionTo(PermissionEnum::PLATFORM_ANALYTICS_VIEW);

        $this->assertFalse(app(PlatformAnalyticsPolicy::class)->viewAny($user));
    }
}
