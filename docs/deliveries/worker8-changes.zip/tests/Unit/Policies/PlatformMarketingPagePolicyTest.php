<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Models\User;
use App\Policies\Cms\Marketing\Platform\PlatformMarketingPagePolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class PlatformMarketingPagePolicyTest extends TestCase
{
    use RefreshDatabase;

    private PlatformMarketingPagePolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(PlatformMarketingPagePolicy::class);
        Permission::findOrCreate(PermissionEnum::MARKETING_PLATFORM_VIEW);
        Permission::findOrCreate(PermissionEnum::MARKETING_PLATFORM_CREATE);
        Permission::findOrCreate(PermissionEnum::MARKETING_PLATFORM_UPDATE);
        Permission::findOrCreate(PermissionEnum::MARKETING_PLATFORM_DELETE);
        Permission::findOrCreate(PermissionEnum::MARKETING_PLATFORM_PUBLISH);
    }

    public function test_user_with_permission_can_view(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::MARKETING_PLATFORM_VIEW);

        $this->assertTrue($this->policy->view($user));
    }

    public function test_user_without_permission_cannot_view_any(): void
    {
        $user = User::factory()->create();

        $this->assertFalse($this->policy->viewAny($user));
    }

    public function test_user_with_permission_can_create(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::MARKETING_PLATFORM_CREATE);

        $this->assertTrue($this->policy->create($user));
    }

    public function test_user_without_permission_cannot_publish(): void
    {
        $user = User::factory()->create();

        $this->assertFalse($this->policy->publish($user));
    }

    public function test_this_policy_has_no_super_admin_bypass_either(): void
    {
        // Pure permission check via HandlesAuthorization — a super_admin role
        // alone is not enough without the explicit MARKETING_PLATFORM_DELETE
        // grant, unlike most store-scoped policies.
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(\App\Enums\RoleEnum::SUPER_ADMIN->value);

        $this->assertFalse($this->policy->delete($superAdmin));
    }
}
