<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Enums\Store\StoreRoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Models\Store;
use App\Models\User;
use App\Policies\MembershipPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class MembershipPolicyTest extends TestCase
{
    use RefreshDatabase;

    private MembershipPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(MembershipPolicy::class);
        Permission::findOrCreate(PermissionEnum::USER_CREATE);
        Permission::findOrCreate(PermissionEnum::USER_BLOCK);
        Permission::findOrCreate(PermissionEnum::USER_DELETE);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    public function test_store_admin_can_view_any_membership(): void
    {
        $admin = User::factory()->merchant()->create();
        $store = Store::factory()->for($admin, 'owner')->create();
        $admin->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);

        $this->assertTrue($this->policy->viewAny($admin, $store));
    }

    public function test_staff_member_cannot_view_any_membership(): void
    {
        $staff = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $staff->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);

        $this->assertFalse($this->policy->viewAny($staff, $store));
    }

    public function test_customer_actor_cannot_view_any_membership_even_as_admin_role_row(): void
    {
        // isMerchant() gate: a customer actor context can never pass, even if a
        // stray store_admin pivot row exists for them.
        $customer = User::factory()->customer()->create();
        $store = Store::factory()->create();
        $customer->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);

        $this->assertFalse($this->policy->viewAny($customer, $store));
    }

    public function test_super_admin_can_create_membership(): void
    {
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);
        $store = Store::factory()->create();

        $this->assertTrue($this->policy->create($superAdmin, $store));
    }

    public function test_store_admin_with_permission_can_create_membership(): void
    {
        $admin = User::factory()->merchant()->create();
        $store = Store::factory()->for($admin, 'owner')->create();
        $admin->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $admin->givePermissionTo(PermissionEnum::USER_CREATE);

        $this->assertTrue($this->policy->create($admin, $store));
    }

    public function test_member_without_permission_throws_on_create(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $member = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $member->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);

        $this->policy->create($member, $store);
    }

    public function test_non_member_cannot_delete_membership(): void
    {
        $stranger = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $stranger->givePermissionTo(PermissionEnum::USER_DELETE);

        $this->assertFalse($this->policy->delete($stranger, $store));
    }

    public function test_store_admin_with_permission_can_update_block_membership(): void
    {
        $admin = User::factory()->merchant()->create();
        $store = Store::factory()->for($admin, 'owner')->create();
        $admin->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $admin->givePermissionTo(PermissionEnum::USER_BLOCK);

        $this->assertTrue($this->policy->update($admin, $store));
    }
}
