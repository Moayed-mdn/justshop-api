<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Enums\Store\StoreRoleEnum;
use App\Models\Store;
use App\Models\User;
use App\Policies\DashboardPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class DashboardPolicyTest extends TestCase
{
    use RefreshDatabase;

    private DashboardPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(DashboardPolicy::class);
        Permission::findOrCreate(PermissionEnum::DASHBOARD_VIEW);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    public function test_super_admin_can_view_stats_without_membership(): void
    {
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);
        $store = Store::factory()->create();

        $this->assertTrue($this->policy->viewStats($superAdmin, $store));
    }

    public function test_member_with_permission_can_view_stats(): void
    {
        $member = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $member->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);
        $member->givePermissionTo(PermissionEnum::DASHBOARD_VIEW);

        $this->assertTrue($this->policy->viewStats($member, $store));
    }

    public function test_member_without_permission_cannot_view_stats(): void
    {
        // Unlike most other store policies, DashboardPolicy::canView() does not
        // route a permission-less member through denyWithContext() — it simply
        // returns false. No exception is thrown here.
        $member = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $member->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);

        $this->assertFalse($this->policy->viewStats($member, $store));
    }

    public function test_non_member_cannot_view_recent_orders(): void
    {
        $stranger = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $stranger->givePermissionTo(PermissionEnum::DASHBOARD_VIEW);

        $this->assertFalse($this->policy->viewRecentOrders($stranger, $store));
    }

    public function test_member_with_permission_can_view_top_products(): void
    {
        $member = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $member->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);
        $member->givePermissionTo(PermissionEnum::DASHBOARD_VIEW);

        $this->assertTrue($this->policy->viewTopProducts($member, $store));
    }
}
