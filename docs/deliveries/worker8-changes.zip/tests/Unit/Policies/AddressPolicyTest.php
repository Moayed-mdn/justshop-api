<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Models\Address;
use App\Models\User;
use App\Policies\AddressPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AddressPolicyTest extends TestCase
{
    use RefreshDatabase;

    private AddressPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        $this->policy = app(AddressPolicy::class);
    }

    public function test_owner_can_view_own_address(): void
    {
        $user = User::factory()->customer()->create();
        $address = Address::factory()->for($user)->create();

        $this->assertTrue($this->policy->view($user, $address));
    }

    public function test_non_owner_cannot_view_address(): void
    {
        $user = User::factory()->customer()->create();
        $owner = User::factory()->customer()->create();
        $address = Address::factory()->for($owner)->create();

        $this->assertFalse($this->policy->view($user, $address));
    }

    public function test_owner_can_update_own_address(): void
    {
        $user = User::factory()->customer()->create();
        $address = Address::factory()->for($user)->create();

        $this->assertTrue($this->policy->update($user, $address));
    }

    public function test_non_owner_cannot_update_address(): void
    {
        $user = User::factory()->customer()->create();
        $owner = User::factory()->customer()->create();
        $address = Address::factory()->for($owner)->create();

        $this->assertFalse($this->policy->update($user, $address));
    }

    public function test_owner_can_delete_own_address(): void
    {
        $user = User::factory()->customer()->create();
        $address = Address::factory()->for($user)->create();

        $this->assertTrue($this->policy->delete($user, $address));
    }

    public function test_non_owner_cannot_delete_address(): void
    {
        $user = User::factory()->customer()->create();
        $owner = User::factory()->customer()->create();
        $address = Address::factory()->for($owner)->create();

        $this->assertFalse($this->policy->delete($user, $address));
    }

    public function test_this_policy_has_no_super_admin_bypass(): void
    {
        // Note for reviewers: AddressPolicy is a pure ownership check with no
        // hasRole(SUPER_ADMIN) shortcut anywhere, unlike most store-scoped
        // policies. A platform admin cannot view/update/delete a customer's
        // address through this policy at all. Confirms current behavior;
        // flag if platform support tooling actually needs this access.
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(\App\Enums\RoleEnum::SUPER_ADMIN->value);
        $owner = User::factory()->customer()->create();
        $address = Address::factory()->for($owner)->create();

        $this->assertFalse($this->policy->view($superAdmin, $address));
    }
}
