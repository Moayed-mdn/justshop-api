<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Models\Cms\MarketingPage;
use App\Models\User;
use App\Policies\MarketingPagePolicy;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

/**
 * IMPORTANT FINDING for reviewers, not an AI-theater artifact:
 *
 * App\Models\Cms\MarketingPage (used by this policy, by
 * MarketingPageRepository, by the Create/Update/Publish/Get/ResolveBySlug
 * actions, and by AdminMarketingPageController) has NO corresponding
 * migration anywhere in database/migrations. Only `platform_marketing_pages`
 * and `store_marketing_pages` exist (the newer split architecture).
 * App\Console\Commands\Cms\MigratePlatformMarketingCommand even describes
 * this model as "the legacy system" it migrates FROM.
 *
 * On a fresh install (or this test suite's sqlite database), any code path
 * that actually queries/persists App\Models\Cms\MarketingPage will throw a
 * "no such table: marketing_pages" QueryException. This looks like leftover
 * dead code from an incomplete migration to the Platform/Store split, not an
 * intentional design. Recommend either restoring the migration (if the old
 * single-table admin flow is still meant to work) or deleting the old
 * model/policy/repository/actions/controller in favor of the split
 * PlatformMarketingPagePolicy / StoreMarketingPagePolicy — that is a product
 * decision, not something this test suite should decide unilaterally.
 *
 * The policy's own authorization logic below (pure permission checks, no DB
 * access) is tested against an in-memory, unsaved model instance so it does
 * not depend on the missing table. The final test proves the table really is
 * missing, so this stays a visible, actionable failure until fixed rather
 * than a silent landmine.
 */
class MarketingPagePolicyTest extends TestCase
{
    use RefreshDatabase;

    private MarketingPagePolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(MarketingPagePolicy::class);
        Permission::findOrCreate(PermissionEnum::CMS_PAGE_VIEW);
        Permission::findOrCreate(PermissionEnum::CMS_PAGE_CREATE);
        Permission::findOrCreate(PermissionEnum::CMS_PAGE_UPDATE);
        Permission::findOrCreate(PermissionEnum::CMS_PAGE_DELETE);
        Permission::findOrCreate(PermissionEnum::CMS_PAGE_PUBLISH);
    }

    public function test_user_with_permission_can_view_any_pages(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::CMS_PAGE_VIEW);

        $this->assertTrue($this->policy->viewAny($user));
    }

    public function test_user_without_permission_cannot_create_a_page(): void
    {
        $user = User::factory()->create();

        $this->assertFalse($this->policy->create($user));
    }

    public function test_user_with_permission_can_view_an_unsaved_page_instance(): void
    {
        // The policy method itself never touches the database, so a plain
        // (unsaved) model instance is enough to exercise its logic.
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::CMS_PAGE_VIEW);
        $page = new MarketingPage(['title' => ['en' => 'Test']]);

        $this->assertTrue($this->policy->view($user, $page));
    }

    public function test_regression_marketing_pages_table_does_not_exist(): void
    {
        $this->expectException(QueryException::class);

        MarketingPage::create(['title' => ['en' => 'x'], 'slug' => ['en' => 'x'], 'sections' => []]);
    }
}
