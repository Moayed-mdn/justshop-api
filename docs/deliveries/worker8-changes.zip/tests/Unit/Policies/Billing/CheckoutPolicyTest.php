<?php

declare(strict_types=1);

namespace Tests\Unit\Policies\Billing;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Models\BillingAccount;
use App\Models\User;
use App\Policies\Billing\CheckoutPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class CheckoutPolicyTest extends TestCase
{
    use RefreshDatabase;

    private CheckoutPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(CheckoutPolicy::class);
        Permission::findOrCreate(PermissionEnum::SUBSCRIPTION_UPGRADE);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    private function makeBillingAccount(User $owner): BillingAccount
    {
        return BillingAccount::create([
            'owner_user_id' => $owner->id,
            'billing_email' => 'billing@example.test',
            'status' => 'active',
        ]);
    }

    public function test_super_admin_can_create_checkout_session(): void
    {
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);
        $account = $this->makeBillingAccount(User::factory()->merchant()->create());

        $this->assertTrue($this->policy->createSession($superAdmin, $account));
    }

    public function test_owner_with_permission_can_create_checkout_session(): void
    {
        $owner = User::factory()->merchant()->create();
        $owner->givePermissionTo(PermissionEnum::SUBSCRIPTION_UPGRADE);
        $account = $this->makeBillingAccount($owner);

        $this->assertTrue($this->policy->createSession($owner, $account));
    }

    public function test_owner_without_permission_is_denied(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $owner = User::factory()->merchant()->create();
        $account = $this->makeBillingAccount($owner);

        $this->policy->createSession($owner, $account);
    }

    public function test_unrelated_user_cannot_create_checkout_session_for_someone_elses_account(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $stranger = User::factory()->merchant()->create();
        $stranger->givePermissionTo(PermissionEnum::SUBSCRIPTION_UPGRADE);
        $account = $this->makeBillingAccount(User::factory()->merchant()->create());

        $this->policy->createSession($stranger, $account);
    }
}
