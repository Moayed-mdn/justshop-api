<?php

declare(strict_types=1);

namespace Tests\Unit\Policies\Billing;

use App\Enums\Billing\InvoiceStatusEnum;
use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Models\BillingAccount;
use App\Models\Invoice;
use App\Models\User;
use App\Policies\Billing\InvoicePolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class InvoicePolicyTest extends TestCase
{
    use RefreshDatabase;

    private InvoicePolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(InvoicePolicy::class);
        Permission::findOrCreate(PermissionEnum::INVOICE_VIEW);
        Permission::findOrCreate(PermissionEnum::INVOICE_DOWNLOAD);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    private function makeBillingAccount(User $owner): BillingAccount
    {
        return BillingAccount::create([
            'owner_user_id' => $owner->id,
            'billing_email' => 'billing@example.test',
            'status' => 'active',
        ]);
    }

    private function makeInvoice(BillingAccount $account): Invoice
    {
        return Invoice::create([
            'billing_account_id' => $account->id,
            'status' => InvoiceStatusEnum::PAID->value,
        ]);
    }

    public function test_owner_with_permission_can_view_any_invoices(): void
    {
        $owner = User::factory()->merchant()->create();
        $owner->givePermissionTo(PermissionEnum::INVOICE_VIEW);
        $account = $this->makeBillingAccount($owner);

        $this->assertTrue($this->policy->viewAny($owner, $account));
    }

    public function test_owner_without_permission_cannot_view_any_invoices(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $owner = User::factory()->merchant()->create();
        $account = $this->makeBillingAccount($owner);

        $this->policy->viewAny($owner, $account);
    }

    public function test_owner_with_permission_can_view_a_specific_invoice(): void
    {
        $owner = User::factory()->merchant()->create();
        $owner->givePermissionTo(PermissionEnum::INVOICE_VIEW);
        $account = $this->makeBillingAccount($owner);
        $invoice = $this->makeInvoice($account);

        $this->assertTrue($this->policy->view($owner, $invoice));
    }

    public function test_unrelated_user_cannot_view_someone_elses_invoice(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $stranger = User::factory()->merchant()->create();
        $stranger->givePermissionTo(PermissionEnum::INVOICE_VIEW);
        $account = $this->makeBillingAccount(User::factory()->merchant()->create());
        $invoice = $this->makeInvoice($account);

        $this->policy->view($stranger, $invoice);
    }

    public function test_super_admin_can_download_any_invoice(): void
    {
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);
        $account = $this->makeBillingAccount(User::factory()->merchant()->create());
        $invoice = $this->makeInvoice($account);

        $this->assertTrue($this->policy->download($superAdmin, $invoice));
    }

    public function test_owner_needs_the_download_specific_permission_not_just_view(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $owner = User::factory()->merchant()->create();
        $owner->givePermissionTo(PermissionEnum::INVOICE_VIEW); // view, not download
        $account = $this->makeBillingAccount($owner);
        $invoice = $this->makeInvoice($account);

        $this->policy->download($owner, $invoice);
    }
}
