<?php

declare(strict_types=1);

namespace Tests\Unit\Policies\Billing;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Enums\Store\StoreRoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Models\BillingAccount;
use App\Models\Store;
use App\Models\User;
use App\Policies\Billing\SubscriptionPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class SubscriptionPolicyTest extends TestCase
{
    use RefreshDatabase;

    private SubscriptionPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(SubscriptionPolicy::class);
        Permission::findOrCreate(PermissionEnum::SUBSCRIPTION_VIEW);
        Permission::findOrCreate(PermissionEnum::SUBSCRIPTION_UPGRADE);
        Permission::findOrCreate(PermissionEnum::SUBSCRIPTION_DOWNGRADE);
        Permission::findOrCreate(PermissionEnum::SUBSCRIPTION_CANCEL);
        Permission::findOrCreate(PermissionEnum::SUBSCRIPTION_RESUME);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    private function makeBillingAccount(User $owner): BillingAccount
    {
        return BillingAccount::create([
            'owner_user_id' => $owner->id,
            'billing_email' => 'billing@example.test',
            'status' => 'active',
        ]);
    }

    public function test_owner_with_permission_can_view_subscription(): void
    {
        $owner = User::factory()->merchant()->create();
        $owner->givePermissionTo(PermissionEnum::SUBSCRIPTION_VIEW);
        $account = $this->makeBillingAccount($owner);

        $this->assertTrue($this->policy->view($owner, $account));
    }

    public function test_owner_with_permission_can_view_usage(): void
    {
        $owner = User::factory()->merchant()->create();
        $owner->givePermissionTo(PermissionEnum::SUBSCRIPTION_VIEW);
        $account = $this->makeBillingAccount($owner);

        $this->assertTrue($this->policy->viewUsage($owner, $account));
    }

    public function test_member_of_a_linked_store_with_permission_can_upgrade(): void
    {
        $owner = User::factory()->merchant()->create();
        $account = $this->makeBillingAccount($owner);
        $store = Store::factory()->for($owner, 'owner')->create();
        $member = User::factory()->merchant()->create();
        $member->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);
        $member->givePermissionTo(PermissionEnum::SUBSCRIPTION_UPGRADE);

        $this->assertTrue($this->policy->upgrade($member, $account, $store));
    }

    public function test_non_member_upgrading_throws_even_with_zero_relation_to_store(): void
    {
        // Every branch of upgrade()/downgrade() ends in denyWithContext() —
        // there is no silent-false path, unlike most HasStoreMembership
        // policies. A complete stranger always gets a PermissionDeniedException.
        $this->expectException(PermissionDeniedException::class);

        $stranger = User::factory()->merchant()->create();
        $stranger->givePermissionTo(PermissionEnum::SUBSCRIPTION_UPGRADE);
        $account = $this->makeBillingAccount(User::factory()->merchant()->create());
        $unrelatedStore = Store::factory()->create();

        $this->policy->upgrade($stranger, $account, $unrelatedStore);
    }

    public function test_member_without_permission_throws_on_downgrade(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $owner = User::factory()->merchant()->create();
        $account = $this->makeBillingAccount($owner);
        $store = Store::factory()->for($owner, 'owner')->create();
        $member = User::factory()->merchant()->create();
        $member->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);

        $this->policy->downgrade($member, $account, $store);
    }

    public function test_owner_with_permission_can_cancel_subscription(): void
    {
        $owner = User::factory()->merchant()->create();
        $owner->givePermissionTo(PermissionEnum::SUBSCRIPTION_CANCEL);
        $account = $this->makeBillingAccount($owner);

        $this->assertTrue($this->policy->cancel($owner, $account));
    }

    public function test_owner_with_permission_can_resume_subscription(): void
    {
        $owner = User::factory()->merchant()->create();
        $owner->givePermissionTo(PermissionEnum::SUBSCRIPTION_RESUME);
        $account = $this->makeBillingAccount($owner);

        $this->assertTrue($this->policy->resume($owner, $account));
    }

    public function test_super_admin_can_move_to_current_version_for_any_account(): void
    {
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);
        $account = $this->makeBillingAccount(User::factory()->merchant()->create());

        $this->assertTrue($this->policy->moveToCurrentVersion($superAdmin, $account));
    }

    public function test_unrelated_user_cannot_cancel_someone_elses_subscription(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $stranger = User::factory()->merchant()->create();
        $stranger->givePermissionTo(PermissionEnum::SUBSCRIPTION_CANCEL);
        $account = $this->makeBillingAccount(User::factory()->merchant()->create());

        $this->policy->cancel($stranger, $account);
    }
}
