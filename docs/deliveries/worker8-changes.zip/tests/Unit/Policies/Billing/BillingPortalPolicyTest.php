<?php

declare(strict_types=1);

namespace Tests\Unit\Policies\Billing;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Enums\Store\StoreRoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Models\BillingAccount;
use App\Models\Store;
use App\Models\User;
use App\Policies\Billing\BillingPortalPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class BillingPortalPolicyTest extends TestCase
{
    use RefreshDatabase;

    private BillingPortalPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(BillingPortalPolicy::class);
        Permission::findOrCreate(PermissionEnum::BILLING_PORTAL);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    private function makeBillingAccount(User $owner): BillingAccount
    {
        return BillingAccount::create([
            'owner_user_id' => $owner->id,
            'billing_email' => 'billing@example.test',
            'status' => 'active',
        ]);
    }

    public function test_super_admin_can_create_session_without_permission(): void
    {
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);
        $account = $this->makeBillingAccount(User::factory()->merchant()->create());

        $this->assertTrue($this->policy->createSession($superAdmin, $account));
    }

    public function test_owner_with_permission_can_create_session(): void
    {
        $owner = User::factory()->merchant()->create();
        $owner->givePermissionTo(PermissionEnum::BILLING_PORTAL);
        $account = $this->makeBillingAccount($owner);

        $this->assertTrue($this->policy->createSession($owner, $account));
    }

    public function test_owner_without_permission_is_denied(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $owner = User::factory()->merchant()->create();
        $account = $this->makeBillingAccount($owner);

        $this->policy->createSession($owner, $account);
    }

    public function test_store_member_linked_via_entitlement_snapshot_can_create_session(): void
    {
        $owner = User::factory()->merchant()->create();
        $account = $this->makeBillingAccount($owner);
        $store = Store::factory()->for($owner, 'owner')->create();
        \App\Models\StoreEntitlementSnapshot::create([
            'store_id' => $store->id,
            'billing_account_id' => $account->id,
            'entitlement_status' => \App\Enums\Entitlement\EntitlementStatusEnum::ENTITLED,
            'features' => [],
        ]);
        $member = User::factory()->merchant()->create();
        $member->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);
        $member->givePermissionTo(PermissionEnum::BILLING_PORTAL);

        $this->assertTrue($this->policy->createSession($member, $account));
    }

    public function test_unrelated_user_with_permission_cannot_create_session(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $stranger = User::factory()->merchant()->create();
        $stranger->givePermissionTo(PermissionEnum::BILLING_PORTAL);
        $account = $this->makeBillingAccount(User::factory()->merchant()->create());

        $this->policy->createSession($stranger, $account);
    }
}
