<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\RoleEnum;
use App\Enums\Store\StoreRoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Models\Store;
use App\Models\User;
use App\Policies\StorePolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class StorePolicyTest extends TestCase
{
    use RefreshDatabase;

    private StorePolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(StorePolicy::class);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    public function test_customer_cannot_view_any_store(): void
    {
        $customer = User::factory()->customer()->create();

        $this->assertFalse($this->policy->viewAny($customer));
    }

    public function test_owner_can_view_own_store(): void
    {
        $owner = User::factory()->merchant()->create();
        $store = Store::factory()->for($owner, 'owner')->create();

        $this->assertTrue($this->policy->view($owner, $store));
    }

    public function test_member_can_view_store(): void
    {
        $member = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $member->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);

        $this->assertTrue($this->policy->view($member, $store));
    }

    public function test_non_member_cannot_view_store(): void
    {
        $stranger = User::factory()->merchant()->create();
        $store = Store::factory()->create();

        $this->assertFalse($this->policy->view($stranger, $store));
    }

    public function test_customer_cannot_view_store_even_if_related(): void
    {
        $customer = User::factory()->customer()->create();
        $store = Store::factory()->create();

        $this->assertFalse($this->policy->view($customer, $store));
    }

    public function test_merchant_without_billing_account_can_create_store(): void
    {
        // FeatureGateService::ensureAccountQuota() returns silently when the user
        // has no BillingAccount yet (treated as "first resource = allowed").
        $merchant = User::factory()->merchant()->create();

        $this->assertTrue($this->policy->create($merchant));
    }

    public function test_customer_cannot_create_store(): void
    {
        $customer = User::factory()->customer()->create();

        $this->assertFalse($this->policy->create($customer));
    }

    public function test_owner_can_update_store(): void
    {
        $owner = User::factory()->merchant()->create();
        $store = Store::factory()->for($owner, 'owner')->create();

        $this->assertTrue($this->policy->update($owner, $store));
    }

    public function test_member_who_is_not_admin_cannot_update_store(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $member = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $member->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);

        $this->policy->update($member, $store);
    }

    public function test_owner_can_delete_store(): void
    {
        $owner = User::factory()->merchant()->create();
        $store = Store::factory()->for($owner, 'owner')->create();

        $this->assertTrue($this->policy->delete($owner, $store));
    }

    public function test_non_owner_admin_cannot_delete_store(): void
    {
        // Only the owner (or an active governed impersonation) can delete —
        // being a plain store_admin member is not enough.
        $this->expectException(PermissionDeniedException::class);

        $admin = User::factory()->merchant()->create();
        $owner = User::factory()->merchant()->create();
        $store = Store::factory()->for($owner, 'owner')->create();
        $admin->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);

        $this->policy->delete($admin, $store);
    }

    public function test_restore_never_succeeds_even_for_the_owner(): void
    {
        // Finding: StorePolicy::restore() has no branch that returns true for
        // anyone, including the store owner or a super_admin without active
        // impersonation. This may be intentional (stores are meant to be
        // restored only through a separate support/platform flow), but it is
        // worth confirming with the team since every sibling policy's restore()
        // does have a real "allowed" path.
        $owner = User::factory()->merchant()->create();
        $store = Store::factory()->for($owner, 'owner')->create();

        $this->assertFalse($this->policy->restore($owner, $store));
    }

    public function test_force_delete_never_succeeds_even_for_the_owner(): void
    {
        $owner = User::factory()->merchant()->create();
        $store = Store::factory()->for($owner, 'owner')->create();

        $this->assertFalse($this->policy->forceDelete($owner, $store));
    }

    public function test_customer_cannot_switch_store(): void
    {
        $customer = User::factory()->customer()->create();
        $store = Store::factory()->create();

        $this->assertFalse($this->policy->switchStore($customer, $store));
    }

    public function test_member_can_switch_to_active_store(): void
    {
        $member = User::factory()->merchant()->create();
        $store = Store::factory()->create(['is_active' => true]);
        $member->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);

        $this->assertTrue($this->policy->switchStore($member, $store));
    }

    public function test_member_cannot_switch_to_inactive_store(): void
    {
        $member = User::factory()->merchant()->create();
        $store = Store::factory()->create(['is_active' => false]);
        $member->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);

        $this->assertFalse($this->policy->switchStore($member, $store));
    }
}
