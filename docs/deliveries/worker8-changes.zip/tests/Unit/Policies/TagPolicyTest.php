<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Enums\Store\StoreRoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Models\Store;
use App\Models\User;
use App\Policies\TagPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class TagPolicyTest extends TestCase
{
    use RefreshDatabase;

    private TagPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(TagPolicy::class);
        Permission::findOrCreate(PermissionEnum::TAG_VIEW);
        Permission::findOrCreate(PermissionEnum::TAG_CREATE);
        Permission::findOrCreate(PermissionEnum::TAG_UPDATE);
        Permission::findOrCreate(PermissionEnum::TAG_DELETE);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    public function test_super_admin_can_view_without_membership(): void
    {
        $user = User::factory()->create();
        $user->assignRole(RoleEnum::SUPER_ADMIN->value);
        $store = Store::factory()->create();

        $this->assertTrue($this->policy->view($user, $store));
    }

    public function test_store_admin_with_permission_can_view(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->for($user, 'owner')->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $user->givePermissionTo(PermissionEnum::TAG_VIEW);

        $this->assertTrue($this->policy->view($user, $store));
    }

    public function test_member_without_permission_throws_on_view(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $user = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STAFF->value]);

        $this->policy->view($user, $store);
    }

    public function test_non_member_cannot_view(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $user->givePermissionTo(PermissionEnum::TAG_VIEW);

        $this->assertFalse($this->policy->view($user, $store));
    }

    public function test_non_member_cannot_create(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->create();
        $user->givePermissionTo(PermissionEnum::TAG_CREATE);

        $this->assertFalse($this->policy->create($user, $store));
    }

    public function test_store_admin_can_create_update_delete_with_permission(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->for($user, 'owner')->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);
        $user->givePermissionTo([
            PermissionEnum::TAG_CREATE,
            PermissionEnum::TAG_UPDATE,
            PermissionEnum::TAG_DELETE,
        ]);

        $this->assertTrue($this->policy->create($user, $store));
        $this->assertTrue($this->policy->update($user, $store));
        $this->assertTrue($this->policy->delete($user, $store));
    }

    public function test_store_admin_without_matching_permission_cannot_create(): void
    {
        $user = User::factory()->merchant()->create();
        $store = Store::factory()->for($user, 'owner')->create();
        $user->stores()->attach($store->id, ['role' => StoreRoleEnum::STORE_ADMIN->value]);

        $this->assertFalse($this->policy->create($user, $store));
    }
}
