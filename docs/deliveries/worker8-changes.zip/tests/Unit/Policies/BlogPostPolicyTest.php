<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Models\BlogPost;
use App\Models\User;
use App\Policies\BlogPostPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class BlogPostPolicyTest extends TestCase
{
    use RefreshDatabase;

    private BlogPostPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(BlogPostPolicy::class);
        Permission::findOrCreate(PermissionEnum::CMS_BLOG_VIEW);
        Permission::findOrCreate(PermissionEnum::CMS_BLOG_CREATE);
        Permission::findOrCreate(PermissionEnum::CMS_BLOG_UPDATE);
        Permission::findOrCreate(PermissionEnum::CMS_BLOG_DELETE);
        Permission::findOrCreate(PermissionEnum::CMS_BLOG_PUBLISH);
    }

    private function makePost(): BlogPost
    {
        return BlogPost::create([
            'title' => ['en' => 'Test Post'],
            'slug' => ['en' => 'test-post'],
            'content' => ['en' => 'Body'],
        ]);
    }

    public function test_user_with_permission_can_view_any_posts(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::CMS_BLOG_VIEW);

        $this->assertTrue($this->policy->viewAny($user));
    }

    public function test_user_without_permission_cannot_create_a_post(): void
    {
        $user = User::factory()->create();

        $this->assertFalse($this->policy->create($user));
    }

    public function test_user_with_permission_can_update_a_post(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::CMS_BLOG_UPDATE);
        $post = $this->makePost();

        $this->assertTrue($this->policy->update($user, $post));
    }

    public function test_user_with_publish_permission_can_publish_a_post(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::CMS_BLOG_PUBLISH);
        $post = $this->makePost();

        $this->assertTrue($this->policy->publish($user, $post));
    }

    public function test_unpublish_and_schedule_reuse_the_publish_permission(): void
    {
        // BlogPostPolicy::unpublish() and schedule() both gate on CMS_BLOG_PUBLISH
        // rather than dedicated permissions — captured explicitly.
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::CMS_BLOG_PUBLISH);
        $post = $this->makePost();

        $this->assertTrue($this->policy->unpublish($user, $post));
        $this->assertTrue($this->policy->schedule($user, $post));
    }

    public function test_user_without_permission_cannot_delete_a_post(): void
    {
        $user = User::factory()->create();
        $post = $this->makePost();

        $this->assertFalse($this->policy->delete($user, $post));
    }
}
