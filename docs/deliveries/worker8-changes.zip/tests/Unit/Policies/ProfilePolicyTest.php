<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Enums\RoleEnum;
use App\Exceptions\Authorization\PermissionDeniedException;
use App\Models\User;
use App\Policies\ProfilePolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class ProfilePolicyTest extends TestCase
{
    use RefreshDatabase;

    private ProfilePolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(ProfilePolicy::class);
        Permission::findOrCreate(PermissionEnum::PROFILE_VIEW);
        Permission::findOrCreate(PermissionEnum::PROFILE_UPDATE_INFO);
        Permission::findOrCreate(PermissionEnum::PROFILE_UPDATE_PASSWORD);
        Permission::findOrCreate(PermissionEnum::PROFILE_UPDATE_AVATAR);
        Permission::findOrCreate(PermissionEnum::PROFILE_DELETE);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    public function test_user_with_permission_can_view_own_profile(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::PROFILE_VIEW);

        $this->assertTrue($this->policy->view($user, $user));
    }

    public function test_user_without_permission_cannot_view_own_profile(): void
    {
        // Same shape as PaymentMethodPolicy: self-access still requires the
        // granular permission to be present on the user. Confirms current
        // behavior; verify the relevant default role grants this permission.
        $this->expectException(PermissionDeniedException::class);

        $user = User::factory()->create();

        $this->policy->view($user, $user);
    }

    public function test_user_cannot_view_someone_elses_profile(): void
    {
        $this->expectException(PermissionDeniedException::class);

        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::PROFILE_VIEW);
        $other = User::factory()->create();

        $this->policy->view($user, $other);
    }

    public function test_super_admin_with_permission_can_view_any_profile(): void
    {
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);
        $superAdmin->givePermissionTo(PermissionEnum::PROFILE_VIEW);
        $other = User::factory()->create();

        $this->assertTrue($this->policy->view($superAdmin, $other));
    }

    public function test_super_admin_without_the_permission_grant_still_cannot_view_others_profile(): void
    {
        // The super_admin branch also requires $user->can(PROFILE_VIEW) — role
        // alone is not sufficient here, unlike most store-scoped policies.
        $this->expectException(PermissionDeniedException::class);

        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);
        $other = User::factory()->create();

        $this->policy->view($superAdmin, $other);
    }

    public function test_user_with_permission_can_update_own_info(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::PROFILE_UPDATE_INFO);

        $this->assertTrue($this->policy->updateInfo($user, $user));
    }

    public function test_user_with_permission_can_update_own_password(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::PROFILE_UPDATE_PASSWORD);

        $this->assertTrue($this->policy->updatePassword($user, $user));
    }

    public function test_user_with_permission_can_delete_own_profile(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::PROFILE_DELETE);

        $this->assertTrue($this->policy->delete($user, $user));
    }
}
