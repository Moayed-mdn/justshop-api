<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\PermissionEnum;
use App\Models\Cms\CmsDocument;
use App\Models\User;
use App\Policies\CmsDocumentPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class CmsDocumentPolicyTest extends TestCase
{
    use RefreshDatabase;

    private CmsDocumentPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(CmsDocumentPolicy::class);
        Permission::findOrCreate(PermissionEnum::CMS_DOC_VIEW);
        Permission::findOrCreate(PermissionEnum::CMS_DOC_CREATE);
        Permission::findOrCreate(PermissionEnum::CMS_DOC_UPDATE);
        Permission::findOrCreate(PermissionEnum::CMS_DOC_DELETE);
        Permission::findOrCreate(PermissionEnum::CMS_DOC_PUBLISH);
    }

    private function makeDocument(): CmsDocument
    {
        return CmsDocument::create([
            'title' => ['en' => 'Test Document'],
            'slug' => ['en' => 'test-document'],
            'content' => ['en' => 'Body'],
        ]);
    }

    public function test_user_with_permission_can_view_any_documents(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::CMS_DOC_VIEW);

        $this->assertTrue($this->policy->viewAny($user));
    }

    public function test_user_without_permission_cannot_view_any_documents(): void
    {
        $user = User::factory()->create();

        $this->assertFalse($this->policy->viewAny($user));
    }

    public function test_user_with_permission_can_create_a_document(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::CMS_DOC_CREATE);

        $this->assertTrue($this->policy->create($user));
    }

    public function test_user_with_permission_can_update_a_document(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::CMS_DOC_UPDATE);
        $document = $this->makeDocument();

        $this->assertTrue($this->policy->update($user, $document));
    }

    public function test_user_without_permission_cannot_delete_a_document(): void
    {
        $user = User::factory()->create();
        $document = $this->makeDocument();

        $this->assertFalse($this->policy->delete($user, $document));
    }

    public function test_user_with_publish_permission_can_publish_a_document(): void
    {
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::CMS_DOC_PUBLISH);
        $document = $this->makeDocument();

        $this->assertTrue($this->policy->publish($user, $document));
    }

    public function test_reorder_uses_the_update_permission_not_a_dedicated_one(): void
    {
        // CmsDocumentPolicy::reorder() reuses CMS_DOC_UPDATE rather than a
        // separate reorder permission — captured explicitly here.
        $user = User::factory()->create();
        $user->givePermissionTo(PermissionEnum::CMS_DOC_UPDATE);

        $this->assertTrue($this->policy->reorder($user));
    }
}
