<?php

declare(strict_types=1);

namespace Tests\Unit\Policies;

use App\Enums\RoleEnum;
use App\Models\Lead;
use App\Models\User;
use App\Policies\LeadPolicy;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Spatie\Permission\Models\Role;
use Spatie\Permission\PermissionRegistrar;
use Tests\TestCase;

class LeadPolicyTest extends TestCase
{
    use RefreshDatabase;

    private LeadPolicy $policy;

    protected function setUp(): void
    {
        parent::setUp();
        app(PermissionRegistrar::class)->forgetCachedPermissions();
        $this->policy = app(LeadPolicy::class);
        Role::findOrCreate(RoleEnum::SUPER_ADMIN->value);
    }

    public function test_super_admin_can_view_any_lead(): void
    {
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);

        $this->assertTrue($this->policy->viewAny($superAdmin));
    }

    public function test_merchant_cannot_view_any_lead(): void
    {
        $merchant = User::factory()->merchant()->create();

        $this->assertFalse($this->policy->viewAny($merchant));
    }

    public function test_customer_cannot_view_a_lead(): void
    {
        $customer = User::factory()->customer()->create();
        $lead = Lead::factory()->create();

        $this->assertFalse($this->policy->view($customer, $lead));
    }

    public function test_super_admin_can_update_a_lead(): void
    {
        $superAdmin = User::factory()->create();
        $superAdmin->assignRole(RoleEnum::SUPER_ADMIN->value);
        $lead = Lead::factory()->create();

        $this->assertTrue($this->policy->update($superAdmin, $lead));
    }

    public function test_merchant_cannot_delete_a_lead(): void
    {
        $merchant = User::factory()->merchant()->create();
        $lead = Lead::factory()->create();

        $this->assertFalse($this->policy->delete($merchant, $lead));
    }
}
